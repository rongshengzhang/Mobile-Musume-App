package com.example.administrator.mobilemuseum;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.administrator.mobilemuseum.R;

// this fragment is for user account activity including login and register
public class MyFragment4 extends Fragment implements View.OnClickListener {
    public MyFragment4() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.settings, container,false);
        Log.e("four", "4");

        FragmentTransaction transaction =getFragmentManager().beginTransaction();
        // replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the backstack
        Button login = view.findViewById(R.id.login);
        Button register = view.findViewById(R.id.register);
        login.setOnClickListener(this);
        register.setOnClickListener(this);

        return view;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register:
                MyFragment5 registerFragment = new MyFragment5();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.rb_login_1, registerFragment);
                transaction.addToBackStack(null);
                transaction.commit();
                break;
            case R.id.login:

                break;
            default:
                break;
        }
    }
}
