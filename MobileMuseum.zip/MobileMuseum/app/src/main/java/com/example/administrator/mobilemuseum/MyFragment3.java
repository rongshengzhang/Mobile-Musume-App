package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.mobilemuseum.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

import static com.example.administrator.mobilemuseum.MyFragment1.EXTRA_MESSAGE;

// this fragment is for exhibition presentation
public class MyFragment3 extends Fragment {
    // URL used for sending request to the server, may need to be changed
    // if server is run in a different machine
    static final String getExhibitionInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getExhibitionInfo/";
    static final String getExhibitionImageURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getExhibitionImage/";
    public static final String EXTRA_MESSAGE = "";

    public MyFragment3() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_content,container,false);
        Log.e("Third", "3");
        new getExhibitionInfo().execute();
        return view;
    }



    // this class is used to send HTTP request to the server and get current exhibition information
    @SuppressLint("StaticFieldLeak")
    private class getExhibitionInfo extends AsyncTask<Void, Void, String> implements View.OnClickListener {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(getExhibitionInfoURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("exhibition", "exhibition");
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf("exhibition"));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = itemInfo;

            if (Objects.equals(temp, "")) {
                Toast.makeText(getContext(),
                        "No exhibition available at the moment",
                        Toast.LENGTH_SHORT).show();
            }
            else if (!temp.contains("not found")) {
                String[] exhibitionInfo = temp.split("@");
                System.out.println(exhibitionInfo.length);
                if (exhibitionInfo.length == 0) {
                    return;
                }
                //noinspection ConstantConditions
                LinearLayout exhibitionLayer = getView().findViewById(R.id.exhibitionLayer);
                // dynamically add item names as buttons and set onClickListener
                int max;
                if (exhibitionInfo.length < 20) {
                    max = exhibitionInfo.length;
                }
                else {
                    max = 20;
                }
                for (int i = 0; i < max; ++i) {
                    Button exhibition = new Button(getContext());
                    if (i == exhibitionInfo.length - 1) {
                        exhibition.setText(exhibitionInfo[i].substring(0, exhibitionInfo[i].length() - 1));
                    }
                    else {
                        exhibition.setText(exhibitionInfo[i]);
                    }
                    exhibition.setId(i);
                    exhibition.setOnClickListener(this);
                    exhibition.setAllCaps(false);
                    exhibitionLayer.addView(exhibition);
                }
            }
            else { // no item found in the favorite list
                Toast.makeText(getContext(),
                        "No exhibition available at the moment",
                        Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onClick(View view) {
            int id = view.getId();
            //noinspection ConstantConditions
            Button item = getView().findViewById(id);
            String message = item.getText().toString();
            message += " ";
            Intent intent = new Intent(getActivity(), ExhibitionPresentation.class);
            intent.putExtra(EXTRA_MESSAGE, message);
            startActivity(intent);
        }
    }
}
