package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

public class ExhibitionPresentation extends Activity {
    String message;
    // URL used for sending request to the server, may need to be changed
    // if server is run in a different machine
    static final String getExhibitionInfoSingleURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getExhibitionInfoSingle/";
    static final String getExhibitionImageURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getExhibitionImage/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exhibition_presentation);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        message = intent.getStringExtra(MyFragment3.EXTRA_MESSAGE);
        if (message.length() > 2) {
            message = message.substring(0, message.length() - 1);
        }
        new getExhibitionInfoSingle().execute();
        new getExhibitionImage().execute();
    }





    // this class is used to send HTTP request to the server and get current exhibition information
    @SuppressLint("StaticFieldLeak")
    private class getExhibitionInfoSingle extends AsyncTask<Void, Void, String> {
        String exhibitionInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(getExhibitionInfoSingleURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("name", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            exhibitionInfo = res.toString();
            return null;
        }



        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            TextView exhibition = findViewById(R.id.exhibitionInfo);
            String temp = exhibitionInfo;

            if (temp == null) {
                exhibition.setText("Exhibition not found...");
            }
            else if (!temp.contains("not found")) {
                exhibition.setText(temp);
            }
            else {
                exhibition.setText("Exhibition not found...");
            }
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class getExhibitionImage extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getExhibitionImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("name", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            ImageView itemImage = findViewById(R.id.exhibitionImage);
            itemImage.setImageDrawable(bitmapDraw);
        }
    }
}
