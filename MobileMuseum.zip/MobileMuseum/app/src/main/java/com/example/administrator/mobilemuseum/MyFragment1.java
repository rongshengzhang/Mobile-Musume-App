package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.administrator.mobilemuseum.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Objects;
import java.util.Random;



// this fragment is for gallery
public class MyFragment1 extends Fragment implements View.OnClickListener {
    /** server's URL for handling the requests */
    static final int item_num = 21;
    static final int item_offset = 1;
    static final String getRandomItemNameURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getRandomItemName/";
    static final String getRandomItemImageURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getRandomItemImage/";

    int index1;
    int index2;
    int index3;
    int index4;
    ImageView image1;
    ImageView image2;
    ImageView image3;
    ImageView image4;
    Button button;
    TextView itemName1;
    TextView itemName2;
    TextView itemName3;
    TextView itemName4;
    public static final String EXTRA_MESSAGE = "";

    public MyFragment1() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.gallery, container, false);
        Log.e("First", "1");
        image1 = view.findViewById(R.id.image1);
        image2 = view.findViewById(R.id.image2);
        image3 = view.findViewById(R.id.image3);
        image4 = view.findViewById(R.id.image4);
        button = view.findViewById(R.id.gallery_refresh);
        itemName1 = view.findViewById(R.id.itemName1);
        itemName2 = view.findViewById(R.id.itemName2);
        itemName3 = view.findViewById(R.id.itemName3);
        itemName4 = view.findViewById(R.id.itemName4);
        image1.setOnClickListener(this);
        image2.setOnClickListener(this);
        image3.setOnClickListener(this);
        image4.setOnClickListener(this);
        button.setOnClickListener(this);
//--------------------------------------------------------------------------------------------------
        displayItemImage();
//--------------------------------------------------------------------------------------------------
        return view;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onClick(View view) {
        Intent intent;
        String message;
        switch (view.getId()) {
            case R.id.gallery_refresh:
                displayItemImage();
                break;
            case R.id.image1:
                intent = new Intent(getActivity(), ItemPresentation.class);
                itemName1 = getView().findViewById(R.id.itemName1);
                message = itemName1.getText().toString();
                intent.putExtra(EXTRA_MESSAGE, message);
                startActivity(intent);
                break;
            case R.id.image2:
                intent = new Intent(getActivity(), ItemPresentation.class);
                itemName2 = getView().findViewById(R.id.itemName2);
                message = itemName2.getText().toString();
                intent.putExtra(EXTRA_MESSAGE, message);
                startActivity(intent);
                break;
            case R.id.image3:
                intent = new Intent(getActivity(), ItemPresentation.class);
                itemName3 = getView().findViewById(R.id.itemName3);
                message = itemName3.getText().toString();
                intent.putExtra(EXTRA_MESSAGE, message);
                startActivity(intent);
                break;
            case R.id.image4:
                intent = new Intent(getActivity(), ItemPresentation.class);
                itemName4 = getView().findViewById(R.id.itemName4);
                message = itemName4.getText().toString();
                intent.putExtra(EXTRA_MESSAGE, message);
                startActivity(intent);
                break;
            default:
                break;
        }
    }



    public void displayItemImage() {
        Calendar c = Calendar.getInstance();
        int second = c.get(Calendar.SECOND);
        Random random = new Random(second);
        index1 = random.nextInt(item_num) + item_offset;
        /* display four groups of names and images as random recommendation */
        new ItemInfo1().execute();
        new ItemImage1().execute();


        index2 = random.nextInt(item_num) + item_offset;
        while (index2 == index1) {
            index2 = random.nextInt(item_num) + item_offset;
        }
        new ItemInfo2().execute();
        new ItemImage2().execute();


        index3 = random.nextInt(item_num) + item_offset;
        while ((index3 == index2) || (index3 == index1)) {
            index3 = random.nextInt(item_num) + item_offset;
        }
        new ItemInfo3().execute();
        new ItemImage3().execute();


        index4 = random.nextInt(item_num) + item_offset;
        while ((index4 == index1) || (index4 == index2) || (index4 == index3)) {
            index4 = random.nextInt(item_num) + item_offset;
        }
        new ItemInfo4().execute();
        new ItemImage4().execute();
    }



    @SuppressLint("StaticFieldLeak")
    private class ItemInfo1 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            String target = getRandomItemNameURL;
            URL url = null;
            String res = "";
            try {
                url = new URL(target);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index1));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res += inputLine + "\n";
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            //TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (Objects.equals(temp, "")) {
                itemName1.setText("Item not found...");
            }
            else if (!temp.contains("not found")) {
                itemName1.setText(temp);
            }
            else {
                itemName1.setText("Item not found...");
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class ItemImage1 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getRandomItemImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index1));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            //ImageView itemImage = getView().findViewById(R.id.item_image2);
            image1.setImageDrawable(bitmapDraw);
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class ItemInfo2 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            String target = getRandomItemNameURL;
            URL url = null;
            String res = "";
            try {
                url = new URL(target);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index2));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res += inputLine + "\n";
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            //TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (Objects.equals(temp, "")) {
                itemName2.setText("Item not found...");
            }
            else if (!temp.contains("not found")) {
                itemName2.setText(temp);
            }
            else {
                itemName2.setText("Item not found...");
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class ItemImage2 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getRandomItemImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index2));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            //ImageView itemImage = getView().findViewById(R.id.item_image2);
            image2.setImageDrawable(bitmapDraw);
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class ItemInfo3 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            String target = getRandomItemNameURL;
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(target);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index3));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            //TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (Objects.equals(temp, "")) {
                itemName3.setText("Item not found...");
            }
            else if (!temp.contains("not found")) {
                itemName3.setText(temp);
            }
            else {
                itemName3.setText("Item not found...");
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class ItemImage3 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getRandomItemImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index3));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            //ImageView itemImage = getView().findViewById(R.id.item_image2);
            image3.setImageDrawable(bitmapDraw);
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class ItemInfo4 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            String target = getRandomItemNameURL;
            URL url = null;
            String res = "";
            try {
                url = new URL(target);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index4));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res += inputLine + "\n";
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            //TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (Objects.equals(temp, "")) {
                itemName4.setText("Item not found...");
            }
            else if (!temp.contains("not found")) {
                itemName4.setText(temp);
            }
            else {
                itemName4.setText("Item not found...");

            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class ItemImage4 extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getRandomItemImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("index", String.valueOf(index4));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(jsonStr.length()));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            //ImageView itemImage = getView().findViewById(R.id.item_image2);
            image4.setImageDrawable(bitmapDraw);
        }
    }
}
