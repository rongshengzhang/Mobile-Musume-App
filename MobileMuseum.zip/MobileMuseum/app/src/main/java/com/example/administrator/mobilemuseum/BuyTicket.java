package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.Random;

import static java.lang.Thread.sleep;

public class BuyTicket extends Activity implements View.OnClickListener {
    static final String buyTicketURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/buyTicket/";
    static final String updateTicketInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/updateTicketInfo/";

    String username = Cookie.get("username", "");
    final Calendar c = Calendar.getInstance();//c is a calendar
    int Year;
    int Month;
    int Day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_ticket);
        Button dateButton = findViewById(R.id.dateButton);
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(0);//when click, display dialog
            }
        });
        Button confirm = findViewById(R.id.confirmPurchasementButton);
        confirm.setOnClickListener(this);
    }



    protected Dialog onCreateDialog(int id){
        return new DatePickerDialog(this, StartingDateSetListener, c.get(Calendar.YEAR),
                                    c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
    }



    private DatePickerDialog.OnDateSetListener StartingDateSetListener =
            new DatePickerDialog.OnDateSetListener(){
                @SuppressLint("SetTextI18n")
                @Override//listener for picking date, when clicking a dialog will pop up
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    //set date when selected
                    Year = year;
                    Month = monthOfYear + 1;//month needs to add 1 due to the converting issues
                    Day = dayOfMonth;
                    TextView date = findViewById(R.id.date);
                    date.setText(String.valueOf(Month) + "/" +
                                 String.valueOf(Day) + "/" +
                                 String.valueOf(Year));
                }
            };



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.confirmPurchasementButton:
                int currYear = c.get(Calendar.YEAR);
                int currMonth = c.get(Calendar.MONTH) + 1;
                int currDay = c.get(Calendar.DAY_OF_MONTH);
                if (currYear != Year) {
                    Toast.makeText(getApplicationContext(),
                            username + ", you can only buy ticket in this year",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    if (currMonth > Month) {
                        Toast.makeText(getApplicationContext(),
                                username + ", man you can't buy tickets for a past day can you??",
                                Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (Month - currMonth > 1) {
                            Toast.makeText(getApplicationContext(),
                                    username + ", you cannot buy ticket for that far future...",
                                    Toast.LENGTH_SHORT).show();
                        }
                        else if (currMonth == Month && currDay >= Day) {
                            Toast.makeText(getApplicationContext(),
                                    username + ", man you can't buy tickets for a past day can you?",
                                    Toast.LENGTH_SHORT).show();
                        }
                        else {
                            new buyTicket().execute();
                        }
                    }
                }
                break;
            default:
                break;
        }
    }


    @SuppressLint("StaticFieldLeak")
    private class buyTicket extends AsyncTask<Void, Void, String> {
        String response = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(buyTicketURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);
                JSONObject jsonObj = new JSONObject();

                EditText text1 = findViewById(R.id.cardNumber);
                EditText text2 = findViewById(R.id.ownerName);
                EditText text3 = findViewById(R.id.cvv);

                String cardNumber = text1.getText().toString();
                String ownerName = text2.getText().toString();
                String cvv = text3.getText().toString();

                jsonObj.put("cardNumber", cardNumber);
                jsonObj.put("ownerName", ownerName);
                jsonObj.put("cvv", cvv);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                //urlConn.setRequestProperty("Content-Length", cardNumber+ownerName+cvv);

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            response = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = response;

            if (temp == null) {
                Toast.makeText(getApplicationContext(),
                        "Invalid card information, please double check!",
                        Toast.LENGTH_SHORT).show();
            }
            else if (temp.contains("success")) {
                new updateTicketInfo().execute();
            }
            else {
                Toast.makeText(getApplicationContext(),
                        "Invalid card information, please double check!",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class updateTicketInfo extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(updateTicketInfoURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);
                JSONObject jsonObj = new JSONObject();

                @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                TextView dateText= findViewById(R.id.date);
                String date = dateText.getText().toString();
                Calendar c = Calendar.getInstance();
                int second = c.get(Calendar.SECOND);
                Random random = new Random(second);
                // generate random verification code for ticket verification
                int code = random.nextInt(499999) + 500000;
                jsonObj.put("username", username);
                jsonObj.put("date", date);
                jsonObj.put("verificationCode", String.valueOf(code));
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(username+date+code));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            if (!itemInfo.contains("fail")) {
                Toast.makeText(getApplicationContext(),
                        username + ", you have successfully bought a ticket for " +
                                String.valueOf(Month) + "/" +
                                String.valueOf(Day) + "/" +
                                String.valueOf(Year),
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(BuyTicket.this, MainActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(getApplicationContext(),
                        username + ", you cannot buy more than three tickets for " +
                                String.valueOf(Month) + "/" +
                                String.valueOf(Day) + "/" +
                                String.valueOf(Year),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }


}
