package com.example.administrator.mobilemuseum;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.administrator.mobilemuseum.R;


public class MyFragment5 extends Fragment implements View.OnClickListener {
    public MyFragment5() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register, container,false);
        Log.e("four", "4");

        return view;
    }


    @Override
    public void onClick(View view) {

    }
}
