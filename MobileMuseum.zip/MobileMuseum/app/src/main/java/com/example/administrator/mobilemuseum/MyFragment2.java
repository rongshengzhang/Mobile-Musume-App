package com.example.administrator.mobilemuseum;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

import static com.example.administrator.mobilemuseum.MyFragment1.EXTRA_MESSAGE;


// this fragment is for searching items
public class MyFragment2 extends Fragment implements View.OnClickListener {
    EditText search_content;
    String message;
    int resultNum = 0;

    /** server's URL for handling the requests */
    static final String getItemInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getItemInfo/";
    static final String getItemImageURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getItemImage/";
    static final String searchItemURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/searchItem/";

    public MyFragment2() {

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.search,container,false);
        Button search_button = (Button)view.findViewById(R.id.search_button);
        search_button.setOnClickListener(this);
        Log.e("second", "2");
        return view;
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.search_button:
                //noinspection ConstantConditions
                search_content = getView().findViewById(R.id.search_content);
                message = search_content.getText().toString();
                LinearLayout layout = getView().findViewById(R.id.searchLayer);
                for (int i = 0; i < resultNum; ++i) {
                    Button temp = getView().findViewById(i);
                    layout.removeView(temp);
                }
                new getFavoriteItemName().execute();
                break;
            default:
                break;
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class getFavoriteItemName extends AsyncTask<Void, Void, String> implements View.OnClickListener {
        String itemInfo = "";
        /** use POST method, send HTTP request to the server and get its response */
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(searchItemURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                if (Objects.equals(message, "")) {
                    return "";
                }
                jsonObj.put("name", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            //TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;
            resultNum = 0;
            if (Objects.equals(temp, "")) {
                Toast.makeText(getContext(),
                        "no item found...please try other key words",
                        Toast.LENGTH_SHORT).show();
            }
            else if (!temp.contains("not found")) {
                String[] itemName = temp.split("@");
                //noinspection ConstantConditions
                LinearLayout favoriteList = getView().findViewById(R.id.searchLayer);
                // dynamically add item names as buttons and set onClickListener
                for (int i = 0; i < itemName.length; ++i) {
                    Button item = new Button(getView().getContext());
                    if (i == itemName.length - 1) {
                        item.setText(itemName[i].substring(0, itemName[i].length() - 1));
                    }
                    else {
                        item.setText(itemName[i]);
                    }
                    item.setId(i);
                    item.setOnClickListener(this);
                    favoriteList.addView(item);
                    ++resultNum;
                }
            }
            else { // no item found in the favorite list
                Toast.makeText(getContext(),
                        "no item found...please try other key words",
                        Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onClick(View view) {
            int id = view.getId();
            @SuppressWarnings("ConstantConditions") Button item = getView().findViewById(id);
            String message = item.getText().toString();
            message += " ";
            Intent intent = new Intent(getActivity(), ItemPresentation.class);
            intent.putExtra(EXTRA_MESSAGE, message);
            startActivity(intent);
        }
    }
}