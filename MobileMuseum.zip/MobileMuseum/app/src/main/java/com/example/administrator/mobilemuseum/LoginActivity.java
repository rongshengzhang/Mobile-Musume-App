package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class LoginActivity extends Fragment implements View.OnClickListener {
    public LoginActivity(){}
    EditText username = null;
    private EditText password = null;
    private Button login = null;
    private Button Register = null;
    private String infotemp = "";
    private boolean log, wait = true;
    static final String loginInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/authentication/";



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login, container, false);
        username = view.findViewById(R.id.editText1);
        password = view.findViewById(R.id.editText2);
        login    = view.findViewById(R.id.button1);
        login.setOnClickListener(this);
        Register = view.findViewById(R.id.button2);
        Register.setOnClickListener(this);
        return view;
    }



    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:
                new Logging().execute();
                break;
            case R.id.button2:
                register(view);
                break;
            default:
                break;
        }
    }



    public void register(View view){
        RegisterActivity registerActivity = new RegisterActivity();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.to_login, registerActivity);
        transaction.addToBackStack(null);
        transaction.commit();
    }



    @SuppressLint("StaticFieldLeak")
    private class Logging extends AsyncTask<Void, Void, String> {
        boolean success = false;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            String Username = username.getText().toString();
            String Password = password.getText().toString();
            System.out.println("username: "+Username);
            System.out.println("password: "+Password);
            URL url = null;
            StringBuilder res = new StringBuilder();
            success = false;
            try {
                url = new URL(loginInfoURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("username",Username);
                jsonObj.put("password",Password);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(Username) + String.valueOf(Password));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }

                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }

            try {
                if (urlConn.getResponseCode() == 200) {
                    success = true;
                    if (res!=null) {
                        Map hfs=urlConn.getHeaderFields();
                        Set<String> keys = hfs.keySet();
                        for(String str:keys) {
                            List<String> vs = (List) hfs.get(str);
                            System.out.print(str + ":");
                            for (String v : vs) {
                                System.out.print(v + "\t");
                            }
                            System.out.println();
                        }
                        String cookie = urlConn.getHeaderField("Set-Cookie");
                        String uname = res.substring(res.indexOf("<uname>")+7,res.indexOf("<uname/>"));
                        //String pic = res.substring(res.indexOf("<avatar>")+7,res.indexOf("<avatar/>"));
                        //System.out.println(pic);
                        System.out.println(uname);
                        //String sessionId = cookie.substring(0, cookie.indexOf(";"));
                        Cookie.set("cookie", cookie);
                        Cookie.set("username", uname);
                        BufferedReader br = new BufferedReader(
                                new InputStreamReader(urlConn.getInputStream()));

                        wait = false;

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            wait = false;
            assert res != null;
            infotemp = res.toString();
            System.out.println(infotemp);
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = infotemp;
            System.out.println("temp:"+temp);
            if(temp == null){
                Toast.makeText(getActivity(), "Please try again!", Toast.LENGTH_SHORT).show();
            }
            else {
                if (success) {
                    System.out.println("succeed checking!!!!");
                    PersonalInfoActivity personalInfoActivity = new PersonalInfoActivity();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.to_login, personalInfoActivity);
                    transaction.addToBackStack(null);
                    transaction.commit();
                    Toast.makeText(getActivity(), "Welcome!", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getActivity(), "Wrong username or password!", Toast.LENGTH_SHORT).show();
                }
            }

        }
    }

}