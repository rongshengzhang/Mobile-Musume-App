package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static java.lang.Thread.sleep;

/**
 * Created by stmagina on 2018/4/9.
 */

public class PersonalInfoActivity extends Fragment implements View.OnClickListener{
    static final String logoutURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/logout/";
    public static String name;
    private boolean wait = false;
    private boolean login = false;
    public PersonalInfoActivity(){}



    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view;
        String cookie = Cookie.get("cookie", "");
        if (!TextUtils.isEmpty(cookie) ) {
            String username = Cookie.get("username", "");
            if(!TextUtils.isEmpty(username) ){
                view = inflater.inflate(R.layout.personalinfo, container,false);
                ImageView imageView = view.findViewById(R.id.imageView);
                imageView.setOnClickListener(this);
                Button logoutButton = view.findViewById(R.id.logout);                   //logout
                logoutButton.setOnClickListener(this);
                Button favouriteButton = view.findViewById(R.id.favourite);                //favourite
                favouriteButton.setOnClickListener(this);
                Button historyButton = view.findViewById(R.id.history);                  //history
                historyButton.setOnClickListener(this);
                Button buyTicketButton = view.findViewById(R.id.buyTicket);                  //buyTicket
                buyTicketButton.setOnClickListener(this);
                Button myTicketButton = view.findViewById(R.id.myTicket);                  //myTicket
                myTicketButton.setOnClickListener(this);
                TextView textView1 = view.findViewById(R.id.Username);
                name = Cookie.get("username", "");
                if(TextUtils.isEmpty(name) ) {
                    textView1.setText("Error:Username Missed!");

                }else {
                    textView1.setText(name);
                }
                login = true;
                return view;

            }

        }
        view = inflater.inflate(R.layout.personallogin, container,false);
        ImageView imageView = view.findViewById(R.id.login_imageView);
        imageView.setOnClickListener(this);
        Button loginButton = view.findViewById(R.id.login);                   //logout
        loginButton.setOnClickListener(this);
        TextView textView1 = view.findViewById(R.id.plz);
        textView1.setText("PLEASE LOGIN");
        login = false;
        Log.e("four", "4");

        @SuppressLint("CommitTransaction") FragmentTransaction transaction =getFragmentManager().beginTransaction();
        // replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the backstack

        return view;
    }



    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.favourite: // jump to favorite items list page
                intent = new Intent(getActivity(), FavoriteItems.class);
                startActivity(intent);
                break;
            case R.id.history: // jump to browsing history
                intent = new Intent(getActivity(), History.class);
                startActivity(intent);
                break;
            case R.id.buyTicket: // jump to browsing history
                intent = new Intent(getActivity(), BuyTicket.class);
                startActivity(intent);
                break;
            case R.id.myTicket: // jump to browsing history
                intent = new Intent(getActivity(), Ticket.class);
                startActivity(intent);
                break;
            case R.id.login:
                LoginActivity login = new LoginActivity();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.personallogin, login);
                transaction.addToBackStack(null);
                transaction.commit();
                break;

            case R.id.logout: // logout: clear cookie and jump to main page
                new Thread(new Runnable(){
                    @Override
                    public void run() {
                        logout();
                    }
                }).start();
                while(wait){
                    try {
                        sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("wait");
                }
                intent = new Intent (getActivity(),MainActivity.class);
                startActivity(intent);
                getActivity().finish();
                wait = true;
                break;
            default:
                break;
        }
    }



    public void logout(){

            /* this is the server's URL for testing now */
        URL url = null;

        try {
            url = new URL(logoutURL);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpURLConnection urlConn = null;
        try {
            assert url != null;
            urlConn = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String cookie = Cookie.get("cookie", "");
        if (!TextUtils.isEmpty(cookie) ) {
            assert urlConn != null;
            urlConn.setRequestProperty("cookie", cookie);
        } else {
            //Intent intent = new Intent(this, MainActivity.class);
            //startActivity(intent);
            LoginActivity loginActivity = new LoginActivity();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.personalinfo, loginActivity);
            transaction.addToBackStack(null);
            transaction.commit();


            return;
        }


        try {
            //establish an HTTP connection
            urlConn.setRequestMethod("POST"); //set HTTP request method to post
            urlConn.setDoOutput(true); // enable outputting data
            urlConn.setDoInput(true);
            urlConn.setUseCaches(false);


            JSONObject jsonObj = new JSONObject();
            String jsonStr = jsonObj.toString();
            byte[] dataSend = jsonStr.getBytes("UTF8");


            // set HTTP post
            // set content type as text, indicating the post data is text data
            urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
            // application/x-www.form-urlencoded is the standard format


            // set the length of content
            urlConn.setRequestProperty("Content-Length", String.valueOf(""));

            //get output stream
            OutputStream outputStream = urlConn.getOutputStream();

            outputStream.write(dataSend); // send data ServiceMode
            outputStream.flush();
            outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------

            if (urlConn.getResponseCode() == 200) { // 200 indicates success

                System.out.println("clean");
                Cookie.set("username","");
                Cookie.set("cookie","");
                wait = false;
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            urlConn.disconnect(); // close the connection
        }

    }



    public String getPath(String path) {
        int index = path.lastIndexOf("/");
        return path.substring(index + 1);
    }
}

