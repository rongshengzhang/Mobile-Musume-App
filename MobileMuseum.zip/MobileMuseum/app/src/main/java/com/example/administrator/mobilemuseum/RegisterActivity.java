package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends Fragment implements View.OnClickListener{
    public RegisterActivity() {
    }
    private EditText username = null;
    private EditText password = null;
    private EditText confirm_password = null;
    private EditText email = null;
    private Button Register = null;
    private String RegisterInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/addUser/";
    private String  infotemp = "";


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_register, container, false);
        //Button button=(Button)view.findViewById(R.id.to_login)
        username = view.findViewById(R.id.editText1);
        password = view.findViewById(R.id.editText2);
        confirm_password = view.findViewById(R.id.editText3);
        email = view.findViewById(R.id.editText4);
        Register = view.findViewById(R.id.button1);
        Register.setOnClickListener(this);
        return view;
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:
                String Username = username.getText().toString();
                String Password = password.getText().toString();
                String confirm  = confirm_password.getText().toString();
                String Email  = email.getText().toString();
                if (Objects.equals(Username, "") || Objects.equals(Password, "") ||
                        Objects.equals(confirm, "") || Objects.equals(Email, "")) {
                    Toast.makeText(getContext(),
                            "Please use valid information to do the registration",
                            Toast.LENGTH_SHORT).show();
                    break;
                }
                else if (!Objects.equals(Password, confirm)) {
                    Toast.makeText(getContext(),
                            "Two passwords are different, please double check",
                            Toast.LENGTH_SHORT).show();
                    break;
                }
                else if (!isEmail(Email)) {
                    Toast.makeText(getContext(),
                            "Please enter valid email address",
                            Toast.LENGTH_SHORT).show();
                    break;
                }
                new Registering().execute();
                break;
            default:
                break;
        }
    }


    public static boolean isEmail(String email){
        if (null==email || "".equals(email)) {
            return false;
        }
        //Pattern p = Pattern.compile("\\w+@(\\w+.)+[a-z]{2,3}"); //简单匹配
        Pattern p =  Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");//复杂匹配
        Matcher m = p.matcher(email);
        return m.matches();
    }




    @SuppressLint("StaticFieldLeak")
    private class Registering extends AsyncTask<Void, Void, String> {
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            String Username = username.getText().toString();
            String Password = password.getText().toString();
            String confirm  = confirm_password.getText().toString();
            String Email  = email.getText().toString();

            String target = RegisterInfoURL;
            URL url = null;
            StringBuilder res = new StringBuilder();

            try {
                url = new URL(target);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("username",Username);
                jsonObj.put("password",Password);
                jsonObj.put("confirm",confirm);
                jsonObj.put("email",Email);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(Username) + String.valueOf(Password) + String.valueOf(email));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }

                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            infotemp = res.toString();
            System.out.println(infotemp);
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = infotemp;
            System.out.println("temp:"+temp);
            if(temp == null){
                Toast.makeText(getActivity(), "temp is NULL!", Toast.LENGTH_SHORT).show();
            }
            else {
                if (temp.charAt(0) == 's') {
                    System.out.println("succeed Registered!!!!");
                    LoginActivity loginActivity = new LoginActivity();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.to_register, loginActivity);
                    transaction.addToBackStack(null);
                    transaction.commit();
                } else if(temp.charAt(0) == 'u'){
                    Toast.makeText(getActivity(), "Username already exists, choose another one!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity(), "The password to confirm is not the same as the former one!", Toast.LENGTH_SHORT).show();
                }

            }

        }
    }
}
