package com.example.administrator.mobilemuseum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class ItemPresentation extends Activity implements View.OnClickListener {
    String message;
    Boolean favorited = false;
    String username = Cookie.get("username", "");

    /** server's URL for handling the requests */
    static final String getItemInfoURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getItemInfo/";
    static final String getItemImageURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/getItemImage/";
    static final String checkFavoriteItemURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/checkFavoriteItem/";
    static final String addFavoriteItemURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/addFavoriteItem/";
    static final String removeFavoriteItemURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/removeFavoriteItem/";
    static final String updateHistoryURL =
            "http://vcm-538.vm.duke.edu:8000/mobile_museum_server/updateHistory/";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_presentation);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        message = intent.getStringExtra(MyFragment1.EXTRA_MESSAGE);
        if (message.length() > 2) {
            message = message.substring(0, message.length() - 1);
        }
        ImageButton favorite = findViewById(R.id.favorite);
        favorite.setOnClickListener(this);
        new ItemInfo().execute();
        new ItemImage().execute();
        String cookie = Cookie.get("cookie", "");
        if (!TextUtils.isEmpty(cookie) ) { // if already logged in
            new checkFavoriteItem().execute();
        }
        new updateHistory().execute();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.favorite:
                String cookie = Cookie.get("cookie", "");
                if (!TextUtils.isEmpty(cookie) ) { // if already logged in
                    if (!favorited) { // not found in the favorite list
                        new addFavoriteItem().execute(); // add item to the favorite list
                        Toast.makeText(getApplicationContext(),
                                "Hi " + username + "! item is now in your favorite list!",
                                Toast.LENGTH_SHORT).show();
                        ImageButton favoriteButton = findViewById(R.id.favorite);
                        favoriteButton.setImageResource(R.drawable.tab_better_pressed1);
                        favorited = true;
                    }
                    else { // already in the favorite list, remove the item
                        new removeFavoriteItem().execute(); // remove the item from favorite list
                        Toast.makeText(getApplicationContext(),
                                "Hi " + username + "! item is removed from your favorite list",
                                Toast.LENGTH_SHORT).show();
                        ImageButton favoriteButton = findViewById(R.id.favorite);
                        favoriteButton.setImageResource(R.drawable.tab_better_normal1);
                        favorited = false;
                    }
                }
                else { // not log in yet
                    Toast.makeText(getApplicationContext(),
                            "Please login first!",
                            Toast.LENGTH_SHORT).show();
                    favorited = false;
                }
                break;

            default:
                break;
        }
    }




    @SuppressLint("StaticFieldLeak")
    private class ItemInfo extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(getItemInfoURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("name", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (temp == null) {
                item_info.setText("Item not found...");
            }
            else if (!temp.contains("not found")) {
                item_info.setText(temp);
            }
            else {
                item_info.setText("Item not found...");
            }
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class ItemImage extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        BitmapDrawable bitmapDraw;
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            String res = "";
            try {
                url = new URL(getItemImageURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("name", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");

                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format

                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output
//--------------------------------------------------------------------------------------------------
                InputStream istream = urlConn.getInputStream();
                // read image data into bitmap and decode
                Bitmap bitmap = BitmapFactory.decodeStream(istream);
                bitmapDraw = new BitmapDrawable(bitmap);
//--------------------------------------------------------------------------------------------------

                istream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res;
            return null;
        }



        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            // display image
            ImageView itemImage = findViewById(R.id.item_image2);
            itemImage.setImageDrawable(bitmapDraw);
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class checkFavoriteItem extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(checkFavoriteItemURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);
                JSONObject jsonObj = new JSONObject();
                jsonObj.put("username", username);
                jsonObj.put("itemName", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(username+message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = itemInfo;
            if (temp == null) {
                favorited = false;
            }
            else if (temp.contains("successfully found")) { // the item is in the favorite list
                // set favorite button to yellow, indicating that the item has been favorited
                ImageButton favoriteButton = findViewById(R.id.favorite);
                favoriteButton.setImageResource(R.drawable.tab_better_pressed1);
                favorited = true;
            }
            else {
                favorited = false;
            }
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class addFavoriteItem extends AsyncTask<Void, Void, String> {
        String itemInfo = "";
        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(addFavoriteItemURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("username", username);
                jsonObj.put("itemName", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(username+message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            TextView item_info = findViewById(R.id.item_info2);
            String temp = itemInfo;

            if (Objects.equals(message, "")) {
                favorited = false;
                return;
            }

            if (Objects.equals(temp, "")) {
                favorited = false;
            }
            else if (!temp.contains("not found")) { // the item is not in the favorite list
                // set favorite button to yellow, indicating that the item has been favorited
                ImageButton favorite = findViewById(R.id.favorite);
                favorite.setImageResource(R.drawable.tab_better_pressed1);
                favorited = true;
            }
            else {
                favorited = false;
            }
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class removeFavoriteItem extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(removeFavoriteItemURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);


                JSONObject jsonObj = new JSONObject();
                jsonObj.put("username", username);
                jsonObj.put("itemName", message);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(username+message));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
            String temp = itemInfo;
            favorited = false;
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class updateHistory extends AsyncTask<Void, Void, String> {
        String itemInfo = "";

        /** use POST method, send HTTP request to the server and get its response */
        @Override
        protected String doInBackground(Void... params) {
            /* this is the server's URL for testing now */
            URL url = null;
            StringBuilder res = new StringBuilder();
            try {
                url = new URL(updateHistoryURL);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpURLConnection urlConn = null;
            try {
                assert url != null;
                urlConn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                //establish an HTTP connection
                assert urlConn != null;
                urlConn.setRequestMethod("POST"); //set HTTP request method to post
                urlConn.setDoOutput(true); // enable outputting data
                urlConn.setDoInput(true);
                urlConn.setUseCaches(false);
                JSONObject jsonObj = new JSONObject();

                Date date = new Date();
                @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                String dateStr = sdf.format(date);

                jsonObj.put("username", username);
                jsonObj.put("itemName", message);
                jsonObj.put("time", dateStr);
                String jsonStr = jsonObj.toString();
                byte[] dataSend = jsonStr.getBytes("UTF8");


                // set HTTP post
                // set content type as text, indicating the post data is text data
                urlConn.setRequestProperty("Content-Type", "application/x-www.form-urlencoded");
                // application/x-www.form-urlencoded is the standard format


                // set the length of content
                urlConn.setRequestProperty("Content-Length", String.valueOf(username+message+dateStr));

                //get output stream
                OutputStream outputStream = urlConn.getOutputStream();

                outputStream.write(dataSend); // send data ServiceMode
                outputStream.flush();
                outputStream.close(); // stop output

//--------------------------------------------------------------------------------------------------
                InputStreamReader inputStream = new InputStreamReader(urlConn.getInputStream()); // get data read
                BufferedReader buffer = new BufferedReader(inputStream); // buffer the input stream
                String inputLine;

                while (((inputLine = buffer.readLine()) != null)) {
                    res.append(inputLine).append("\n");
                }
                inputStream.close(); // stop input stream
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            finally {
                assert urlConn != null;
                urlConn.disconnect(); // close the connection
            }
            itemInfo = res.toString();
            return null;
        }



        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            // this is used to display text sent from main activity
        }
    }

}
